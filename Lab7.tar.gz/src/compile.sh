#!/bin/bash
rm *.x *.a

gfortran -ffixed-line-length-90 -ffree-line-length-90 -O3 -Wall -Wtabs -c parameters.f90 initializations.f90
gfortran -ffixed-line-length-90 -ffree-line-length-90 -O3 -Wall -Wtabs -c *.f*

# create static library using archive(ar) program
ar rv forecast.a *.o

# create program to make forecast
gfortran -ffixed-line-length-90 -ffree-line-length-90 -O3 -Wall -Wtabs forecast.f90 forecast.a -o forecast.x
# rm *.o *.mod
echo "Compilation completed successfully!"